import{default as t}from"../components/pages/_page.svelte-8240e5f6.js";export{t as component};
