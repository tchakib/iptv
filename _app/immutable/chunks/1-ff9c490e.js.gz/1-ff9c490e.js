import{default as t}from"../components/error.svelte-a7192f92.js";export{t as component};
