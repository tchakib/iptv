import{default as t}from"../components/pages/channel/_page.svelte-2fc55ff6.js";export{t as component};
